public class MathInJava {
    public static void main(String[] args) 
    {
        System.out.println("Actual:   " + uglyFraction(3,4));
        System.out.println("Expected: 0.3333333333333333");
        
        System.out.println("Actual:   " + uglierFraction(3,4));
        System.out.println("Expected: 1.1333333333333333");
        
        System.out.println("Actual:   " + average(3, 4, 3, 3));
        System.out.println("Expected: 3.25");
    }
    

    public static  double uglyFraction(double x, double y) 
    {
        // To do!
    }
    
    public static double uglierFraction(double x, double y) 
    {
        // To do! 
    }
    
    public static double average(int a, int b, int c, int d) 
    {
        // To do! 
    }
}