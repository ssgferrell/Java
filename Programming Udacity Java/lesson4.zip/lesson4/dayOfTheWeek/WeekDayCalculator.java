public class WeekDayCalculator
{

    /**
     * Returns the day of the week it will be in daysToAdd days
     * days of the week are prepresented as integers, 
     * Sunday is 0, 
     * Monday is 1, 
     * Tuesday is 2...
     * 
     * @param today the number of today's day of the week
     * @param daysToAdd the number of days to add 
     */
    public int getDayOfTheWeek(int today, int daysToAdd) 
    {
        // Your code here!
        return 0;
    }
}
