// BlueJ project: lesson4/turningMathToJava
// Video: Arithmetic Operations 2

public class MathInJava
{
    /*
       Computes the fraction
           y
       --------
       x(1 + x)
    */
    public double uglyFraction(double x, double y)
    {
        // To do!
    }

    /*
        Computes the fraction
        2 + x(3x - 4)
        -------------
          (x+2)(x)
    */
    public double uglierFraction(double x)
    {
        // To do!
    }

    /**
        Computes the average of four values.
        @param a the first value
        @param b the second value
        @param c the third value
        @param d the average of a, b, c, and d
    */
    public double average(int a, int b, int c, int d)
    {
        // To do!
    }
}
